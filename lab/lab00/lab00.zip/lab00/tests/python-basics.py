test = {
  'name': 'Python Basics',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> x = 20
          >>> x + 2
          3d3ab69a0677d75a0ef4a99e0d2d1451
          # locked
          >>> x
          e1ac00f801290865dd772310ea7c60e4
          # locked
          >>> y = 5
          >>> y = y + 3
          >>> y * 2
          309984ef0dc06025a91b127042939a0e
          # locked
          >>> y + x
          1c1c92ed084737be2f07abf6a2c86c2f
          # locked
          """,
          'hidden': False,
          'locked': True,
          'multiline': False
        }
      ],
      'scored': False,
      'type': 'wwpp'
    }
  ]
}
